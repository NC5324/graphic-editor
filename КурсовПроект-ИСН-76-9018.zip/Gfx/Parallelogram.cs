﻿using CourseProject.Bounds;
using System.Drawing;

namespace CourseProject.Gfx
{
    [System.Serializable]
    public class Parallelogram : Shape
    {
        private PointF A, B, C, D;
        public Parallelogram(Boundary bounds) : base(bounds)
        {
            InitSpecifics();
            PositionChanged += OnBoundaryChanged;
            SizeChanged += OnBoundaryChanged;
        }
        private void OnBoundaryChanged(object sender, System.EventArgs e)
        {
            InitSpecifics();
        }

        public Parallelogram()
        {

        }
        public override void Draw(Graphics gfx)
        {
            Pen pen = new Pen(OutlineColor, OutlineWidth);
            using (pen)
            {
                gfx.DrawPolygon(pen, new[] { A, B, C, D });
            }
            Brush brush = new SolidBrush(FillColor);
            using (brush)
            {
                gfx.FillPolygon(brush, new[] { A, B, C, D });
            }

            base.Draw(gfx);

        }

        protected void InitSpecifics()
        {
            //base.InitSpecifics();
            A = Bounds.DragHandles[DragHandleAnchor.BottomLeft].Location;
            B = new PointF(Bounds.Right - 25.PercentOf(Bounds.Width), Bounds.Bottom);
            C = Bounds.DragHandles[DragHandleAnchor.TopRight].Location;
            D = new PointF(Bounds.Left + 25.PercentOf(Bounds.Width), Bounds.Top);
        }

        internal override Shape Clone(Boundary bounds)
        {
            return new Parallelogram(bounds);
        }
    }
}
