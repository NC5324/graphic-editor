﻿namespace CourseProject.Gfx
{
    public enum Scaling
    {
        Normal = 0, Small, Big
    }
}
