﻿namespace CourseProject.Bounds
{
    public  enum DragHandleAnchor
    {
        None,
        TopLeft,
        TopCenter,
        TopRight,
        MiddleLeft,
        MiddleRight,
        BottomLeft,
        BottomCenter,
        BottomRight
    }
}
