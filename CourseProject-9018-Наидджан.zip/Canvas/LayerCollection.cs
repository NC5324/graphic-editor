﻿using CourseProject.Gfx;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CourseProject
{
    [Serializable]
    public class LayerCollection : IEnumerable<Layer>
    {
        public Dictionary<LayerProperties, Layer> Layers { get; private set; }

        #region Public Constructors
        public LayerCollection()
        {
            Layers = new Dictionary<LayerProperties, Layer>();
            Layers.Add(new LayerProperties("New Layer", true, false, 0), new Layer());
        }
        #endregion

        #region Public Methods
        public void Add(Layer layer)
        {
            if (!Layers.ContainsValue(layer))
                Layers.Add(new LayerProperties("Added Layer", true, false, Layers.Max(x => x.Key.Order) + 1), layer);
        }
        public void Remove(Layer layer)
        {
            if (Layers.ContainsValue(layer))
                Layers.Remove(this[layer]);
        }

        public void MoveUp(Layer layer)
        {
            var properties = this[layer];
            var propOrderPair = Layers.OrderBy(x => x.Key.Order).Select((x, i) => new { x.Key, i });

            var minOrder = propOrderPair.Min(x=>x.Key.Order);
            if (properties.Order == minOrder || !Layers.ContainsKey(properties))
                return;

            var query = propOrderPair.Where(x => x.Key == properties).FirstOrDefault();
            var queryIndex = query.i;
            var queryProperties = query.Key;

            var queryPrev = propOrderPair.FirstOrDefault(x => x.i == queryIndex - 1);
            var prevIndex = queryPrev.i;
            var prevProperties = queryPrev.Key;

            var queryOrder = queryProperties.Order;
            queryProperties.Order = prevProperties.Order;
            prevProperties.Order = queryOrder;
        }

        public void MoveDown(Layer layer)
        {
            var properties = this[layer];
            var propOrderPair = Layers.OrderBy(x => x.Key.Order).Select((x, i) => new { x.Key, i });

            var maxOrder = propOrderPair.Max(x => x.Key.Order);
            if (properties.Order == maxOrder || !Layers.ContainsKey(properties))
                return;

            var query = propOrderPair.Where(x => x.Key == properties).FirstOrDefault();
            var queryIndex = query.i;
            var queryProperties = query.Key;

            var queryNext = propOrderPair.FirstOrDefault(x => x.i == queryIndex + 1);
            var prevIndex = queryNext.i;
            var nextProperties = queryNext.Key;

            var queryOrder = queryProperties.Order;
            queryProperties.Order = nextProperties.Order;
            nextProperties.Order = queryOrder;
        }

        public Layer this[int index]
        {
            get
            {
                var propOrderPair = Layers.OrderBy(x => x.Key.Order).Select((x, i) => new { x.Key, i });
                return Layers[propOrderPair.FirstOrDefault(x=>x.i == index).Key];
            }
            set
            {
                Layers[Layers.FirstOrDefault(x => x.Key.Order == index).Key] = value;
            }
        }

        public LayerProperties this[Layer index]
        {
            get
            {
                return Layers.FirstOrDefault(x => x.Value == index).Key;
            }
        }

        #endregion

        public int IndexOf(Layer layer)
        {
            var propOrderPair = Layers.OrderBy(x => x.Key.Order).Select((x, i) => new { x.Key, i });
            return propOrderPair.FirstOrDefault(x => Layers[x.Key] == layer).i;
        }

        #region Interface Implementation
        public IEnumerator<Layer> GetEnumerator()
        {
            return Layers.Values.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

    }
}
